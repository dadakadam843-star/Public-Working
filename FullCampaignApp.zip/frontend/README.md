# Frontend for Campaign Admin
Open index.html in browser or serve with backend static hosting.
It posts to /api/broadcast endpoint on same domain by default.
